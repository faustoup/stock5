import streamlit as st
from datetime import datetime
from zoneinfo import ZoneInfo
from inventario import consultar,excel,LISTA
st.set_page_config(page_title='Inventario Ledvance')
st.title('Inventario de mi cuenta Ledvance')
import os
from pathlib import Path
from intercambio import leer_csv
remoto=st.radio("¿Dónde corre Streamlit?",["Servidor o Streamlit Cloud","Mi computadora"],horizontal=True)
if remoto=="Servidor o Streamlit Cloud":
    st.write("Consulta Ledvance desde tu sesión de Chrome o Edge. Streamlit convierte las cantidades a Excel sin abrir un navegador en el servidor.")
    paquete=Path(__file__).with_name("Lector_Ledvance.zip")
    st.download_button("1. Descargar extensión de consulta",paquete.read_bytes(),"Lector_Ledvance.zip",mime="application/zip")
    st.markdown("Descomprime el ZIP. En Chrome abre `chrome://extensions` (en Edge, `edge://extensions`), activa **Modo de desarrollador**, pulsa **Cargar descomprimida** y selecciona la carpeta que contiene `manifest.json`.")
    st.markdown("**2.** Abre la extensión desde el menú de extensiones del navegador. Inicia sesión en Ledvance, elige **Prueba: 4 claves**, pulsa **Consultar** y descarga el CSV. Para el inventario completo, elige **421 SKU**.")
    uploaded=st.file_uploader("3. Selecciona el CSV de la extensión",type="csv")
    if uploaded:
        try:
            filas=leer_csv(uploaded.getvalue());n=sum(q is not None for s,q in filas)
            st.write(f"{n} de {len(filas)} SKU con cantidad. Las cantidades desconocidas se conservan vacías.")
            st.download_button("Descargar Excel",excel(filas),"Inventario_Ledvance_"+datetime.now(ZoneInfo("America/Mexico_City")).strftime("%Y%m%d_%H%M")+".xlsx",mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        except ValueError as err:st.error(str(err))
    st.stop()
if os.name=="posix" and not os.environ.get("DISPLAY") and not os.environ.get("WAYLAND_DISPLAY") and __import__("sys").platform.startswith("linux"):
    st.info("Este servidor no tiene escritorio para abrir Ledvance. Elige «Servidor o Streamlit Cloud» arriba.");st.stop()
st.write('Abre esta app en tu computadora. Inicia sesión en la ventana de Ledvance; tu contraseña no se escribe en Streamlit.')
modo=st.radio("Lista de consulta",["Prueba: 4 claves","Lista completa (421 SKU)"])
raw=st.text_area("SKU a consultar · uno por línea",value=("83960\n83961\n88870\n88871" if modo.startswith("Prueba") else LISTA.read_text().strip()),key=modo,height=140)
skus=list(dict.fromkeys(s.strip() for s in raw.splitlines() if s.strip()))
if st.button('Abrir Ledvance y consultar',type='primary',disabled=not skus):
    st.session_state.pop('reporte',None);msg=st.empty()
    try:
        filas,errores=consultar(skus,msg.info)
        fecha=datetime.now(ZoneInfo('America/Mexico_City'));st.session_state.reporte=(tuple(skus),filas,errores,fecha,excel(filas))
    except Exception as err:st.error(f'No se completó la consulta: {err}')
    finally:msg.empty()
if 'reporte' in st.session_state:
    lista,filas,errores,fecha,data=st.session_state.reporte
    if lista==tuple(skus):
        st.write(f'{len(filas)-len(errores)} de {len(filas)} SKU con cantidad. Consulta: {fecha:%d/%m/%Y %H:%M} · Ciudad de México.')
        if errores:
            with st.expander('SKU pendientes (cantidad en blanco)'):
                st.dataframe([{'SKU':s,'Motivo':m} for s,m in errores.items()],hide_index=True)
        st.download_button('Descargar Excel',data,f'Inventario_Ledvance_{fecha:%Y%m%d_%H%M}.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        st.dataframe([{'SKU':s,'Cantidad':q} for s,q in filas],hide_index=True)
