# Inventario Ledvance V5

## Despliegue en Streamlit Cloud
1. Extrae el ZIP principal en tu computadora.
2. Sube los siete archivos extraídos directamente a la raíz del repositorio en GitHub. En esa vista deben aparecer app.py y requirements.txt. Conserva Lector_Ledvance.zip como archivo ZIP junto a app.py.
3. En Streamlit Cloud selecciona ese repositorio y la rama donde subiste los archivos. En Main file path escribe: app.py.

Incluye las claves de prueba 83960, 83961, 88870 y 88871 y la lista completa de 421 SKU. Exporta **SKU** y **Cantidad**; los datos inciertos quedan vacíos. El programa no escribe en Shopify.

## Si usas Streamlit Cloud o un servidor
1. Sustituye los archivos de la V3 en el proyecto de Streamlit por los de esta carpeta, incluido **Lector_Ledvance.zip** (sin descomprimir en el proyecto). Reinicia la app con el mismo punto de entrada, app.py. No hay que instalar Chromium en el servidor.
2. En la app, selecciona **Servidor o Streamlit Cloud**. Descarga y descomprime **Lector_Ledvance.zip en tu computadora**. En Chrome abre `chrome://extensions` o en Edge `edge://extensions`, activa **Modo de desarrollador** y selecciona **Cargar descomprimida**. Elige la carpeta que contiene manifest.json.
3. Abre **Inventario Ledvance · Playlux** desde el menú de extensiones. Entra en tu cuenta usando el enlace a Ledvance y regresa al panel. Pulsa **Consultar** para probar las cuatro claves. La extensión usa una pestaña separada de Ledvance en ese mismo perfil; deja ambas pestañas abiertas hasta terminar. Las cantidades se consultan en fichas visibles, asociadas al SKU y la variante seleccionada. La sesión se comprueba antes y después; si no puede verificarse, la extensión no exporta.
4. Descarga el CSV, cárgalo en la app y pulsa **Descargar Excel**. Solo el CSV llega a Streamlit. Las contraseñas y cookies no se solicitan ni se transfieren a la app. Compara las primeras cantidades con tu cuenta antes de ejecutar la lista completa.

## Si usas Streamlit en tu propia computadora con escritorio
Desde la carpeta del proyecto, con Python 3.10 o posterior, en el mismo entorno ejecuta:
```shell
python -m pip install -r requirements.txt
python -m playwright install chromium
python -m streamlit run app.py --server.address 127.0.0.1
```
Elige **Mi computadora**. En este modo no se necesita extensión: Playwright abre una ventana local para que inicies sesión directamente en Ledvance. En Linux con escritorio, si Playwright indica que faltan bibliotecas del sistema, sigue el mensaje de instalación de dependencias de Playwright.
