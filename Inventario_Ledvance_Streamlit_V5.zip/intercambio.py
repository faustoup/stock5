import csv, io, re

def leer_csv(data):
    if len(data)>1_000_000:raise ValueError("El archivo excede 1 MB.")
    reader=csv.DictReader(io.StringIO(data.decode('utf-8-sig'),newline=''))
    if reader.fieldnames!=['SKU','Cantidad']:raise ValueError('Se esperan las columnas SKU y Cantidad del archivo de la extensión.')
    out=[];seen=set()
    for row in reader:
        sku=row['SKU'];q=row['Cantidad']
        if None in row or q is None or not re.fullmatch(r'[0-9]+',sku or '') or sku in seen or (q and not re.fullmatch(r'[0-9]+',q)):
            raise ValueError(f'Fila inválida o SKU repetido en la línea {reader.line_num}.')
        seen.add(sku);out.append((sku,int(q) if q else None))
    if not out:raise ValueError("El archivo no contiene SKU.")
    return out
